# Ropes
This is a port of Amin Ahmad's Java implementation into C#. The original source code can be found at http://ahmadsoft.org/source/xref/ropes-1.2.5/src/org/ahmadsoft/

The rope data structure is a useful storage system for efficient storage and manipulation of very large strings. You can read more about the background of this structure at Amin's source above or on Wikipedia at https://en.wikipedia.org/wiki/Rope_%28data_structure%29
